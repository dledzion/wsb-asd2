﻿using System;
using System.IO;
using System.Text;
using web_asd_2.Services;

namespace web_asd_2
{
    class Program
    {
        private static readonly string FilePath = Path.Combine(Environment.CurrentDirectory, "./results.csv");
        private static readonly string Header = "AlgorithmName,TestedNumber,Divisions";

        static void Main(string[] args)
        {
            var isPrimeExample = new IsPrimeExample();
            var isPrimeDecent = new IsPrimeDecent();
            var isPrimeOptimal = new IsPrimeOptimal();
            var csv = new StringBuilder();

            csv.AppendLine(Header);

            csv.Append(TestPrime.Test(isPrimeOptimal));
            csv.Append(TestPrime.Test(isPrimeDecent));
            csv.Append(TestPrime.Test(isPrimeExample));
           
            File.WriteAllText(FilePath, csv.ToString());

            Console.WriteLine("\nPress any button to continue...");
            Console.ReadLine();
        }
    }
}
