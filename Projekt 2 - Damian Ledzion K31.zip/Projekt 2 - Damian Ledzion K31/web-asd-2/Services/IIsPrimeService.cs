﻿using System;
using System.Numerics;

namespace web_asd_2.Services
{
    public interface IIsPrimeService
    {
        Tuple<bool, BigInteger> IsPrime(BigInteger num);

        string Name { get; }
    }
}