﻿using System;
using System.Numerics;

namespace web_asd_2.Services
{
    public class IsPrimeExample : IIsPrimeService
    {
        public string Name => "Example";

        public Tuple<bool, BigInteger> IsPrime(BigInteger num)
        {
            BigInteger divisions = 0;

            if (num < 2) return Tuple.Create(false, divisions);
            if (num < 4) return Tuple.Create(true, divisions);

            for (BigInteger u = 3; u < num / 2; u += 2)
            {
                divisions++;
                if (num % u == 0) return Tuple.Create(false, divisions);
            }

            return Tuple.Create(true, divisions);
        }
    }
}
