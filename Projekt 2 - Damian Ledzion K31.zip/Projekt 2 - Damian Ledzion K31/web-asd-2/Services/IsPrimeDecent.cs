﻿using System;
using System.Numerics;

namespace web_asd_2.Services
{
    public class IsPrimeDecent : IIsPrimeService
    {
        string IIsPrimeService.Name => "Decent";

        public Tuple<bool, BigInteger> IsPrime(BigInteger num)
        {
            BigInteger divisions = 0;

            if (num <= 1) return Tuple.Create(false, divisions);
            if (num == 2) return Tuple.Create(true, divisions);
            if (num % 2 == 0) return Tuple.Create(false, divisions);

            var boundary = (int)Math.Floor(Math.Sqrt((double)num));

            for (var i = 3; i <= boundary; i += 2)
            {
                divisions++;
                if (num % i == 0)
                    return Tuple.Create(false, divisions);
            }

            return Tuple.Create(true, divisions);
        }
    }
}
