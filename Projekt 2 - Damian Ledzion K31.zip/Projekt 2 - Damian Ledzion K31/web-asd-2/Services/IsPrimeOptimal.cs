﻿using System;
using System.Numerics;
using web_asd_2.Services;


namespace web_asd_2
{
    public class IsPrimeOptimal : IIsPrimeService
    {
        string IIsPrimeService.Name => "Optimal";

        
        public Tuple<bool, BigInteger> IsPrime(BigInteger num)
        {
            BigInteger divisions = 0;


            if (num <= 1) return Tuple.Create(false, divisions);
            if (num <= 3) return Tuple.Create(true, divisions);
            divisions++;
            if (num % 2 == 0) return Tuple.Create(false, divisions);
            divisions++;
            if (num % 3 == 0) return Tuple.Create(false, divisions);
            for (BigInteger i = 5; i * i <= num; i += 6)
            {
                divisions++;
                if (num % i == 0)
                    return Tuple.Create(false, divisions);
                divisions++;
                if (num % (i + 2) == 0)
                    return Tuple.Create(false, divisions);
            }
            return Tuple.Create(true, divisions);
        }
    }
}
