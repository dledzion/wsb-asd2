﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Numerics;
using System.Text;

namespace web_asd_2.Services
{
    public static class TestPrime
    {
        private static readonly List<BigInteger> TestSet = new List<BigInteger>
        {
           101, 1009, 10091, 100913, 1009139, 10091401, 100914061, 1009140611, 10091406133
        };

        /// <summary>
        /// Runs test for IsPrime methods and returns CSV with statistic results as string
        /// </summary>
        public static string Test(IIsPrimeService isPrimeService)
        {
            Console.WriteLine($"Testing for the {isPrimeService.Name} algorithm.\n");

            var csv = new StringBuilder();
            var stopwatch = Stopwatch.StartNew();

            foreach (var testNum in TestSet)
            {
                var isPrime = isPrimeService.IsPrime(testNum);
                Console.WriteLine($"{testNum}: \t{isPrime.Item1} \tDivisions: {isPrime.Item2}");

                var line = $"{isPrimeService.Name},{testNum.ToString()},{isPrime.Item2}";
                csv.AppendLine(line);
            }

            stopwatch.Stop();
            var timeElapsedMs = stopwatch.ElapsedMilliseconds;
            csv.AppendLine(timeElapsedMs.ToString());

            Console.WriteLine(timeElapsedMs > 1000
                ? $"\nTime elapsed: {stopwatch.ElapsedMilliseconds / 1000} s"
                : $"\nTime elapsed: {stopwatch.ElapsedMilliseconds} ms");

            Console.WriteLine("-----------");

            return csv.ToString();
        }
    }
}
